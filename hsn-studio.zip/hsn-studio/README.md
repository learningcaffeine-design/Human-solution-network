# HSN Studio — scroll-driven cinematic product experience

A single continuous scene, not a normal website: scrolling scrubs a 3D
timeline (`experienceProgress`, 0 → 1) that opens a package, reveals a
sanitary pad, explodes it into five structural layers, dives into the
absorbent core, reconstructs the product, and closes on the brand line.

## Run it

```bash
npm install
npm run dev
```

Open the printed local URL. Build for production with `npm run build`
(outputs to `dist/`), preview that build with `npm run preview`.

## 1. What was built

- **`src/App.jsx`** — mounts the fixed 3D canvas + fixed UI overlay, and a
  tall (`700vh`) invisible spacer element. Scrolling the page scrolls the
  spacer; the spacer's scroll distance is what actually drives the story.
- **`src/components/Experience/`** — the 3D world:
  - `ProductScene.jsx` — the R3F `<Canvas>`, lighting, fog, background.
  - `SanitaryPad.jsx` — the modular product (`<TopSheet/>`-style layer
    group + hinged wrapper flaps + hinged wings), all driven every frame
    from `experienceProgress`.
  - `ProductLayers.jsx` — the five-layer config (`LAYER_CONFIG`): colors,
    opacities, and exploded-view Y offsets, plus the reusable extruded
    layer mesh.
  - `CameraController.jsx` — a camera keyframe track (position/look-at/FOV)
    interpolated by `experienceProgress`, plus a few-pixel mouse parallax.
  - `Particles.jsx` — ambient atmospheric haze.
  - `CoreVisualization.jsx` — the abstract fiber/fluid representation used
    only during the "dive into the core" beat.
- **`src/components/UI/`** — the cinematic text/nav overlay: `IntroText`,
  `StoryText` (reused for every later scene), `ProgressIndicator` (thin
  vertical line + "0X / 06"), `Navigation` (minimal top bar).
- **`src/utils/progressStore.js`** — the single source of truth: a plain
  mutable object (`progressStore.value`, 0 → 1) plus the `TIMELINE` table
  of every scene's start/end breakpoints on that 0 → 1 range, and a
  `mapRange` helper used everywhere to derive per-scene values from it.
- **`src/hooks/useScrollTimeline.js`** — the only place GSAP ScrollTrigger
  is touched. It scrubs the spacer's scroll position into
  `progressStore.value` and calls back into `App.jsx`.
- **`src/sections/`** — one file per scene from the brief (`Hero`,
  `Reveal`, `Layers`, `Core`, `Reconstruction`), each just metadata (an id,
  its point on the master timeline, a nav label). Since this is one
  continuous canvas rather than routed pages, these exist as documented
  waypoints that `Navigation.jsx` scrolls to — not separately mounted
  components.

## 2. How the scroll timeline works

1. `App.jsx` renders a spacer `<div style={{ height: "700vh" }} />`. The
   canvas and UI overlay are `position: fixed`, so they never move — only
   the page's scroll position changes.
2. `useScrollTimeline` creates one `ScrollTrigger` pinned to that spacer's
   scroll range (`start: "top top"` → `end: "bottom bottom"`, `scrub: 0.6`
   for a slight, deliberate lag rather than 1:1 tracking).
3. On every scrub tick, `progressStore.value` is updated directly (no
   React state) and `App.jsx`'s `handleProgress` runs.
4. **3D side:** every `Experience` component reads `progressStore.value`
   inside its own `useFrame` and derives its own local animation state
   with `mapRange(progress, sceneStart, sceneEnd, from, to)` — e.g. wing
   rotation, layer Y-offset, camera position. Nothing here is React state,
   so scrolling never re-renders the component tree.
5. **UI side:** `App.jsx` holds a plain DOM `ref` per text block and calls
   `fadeWindow(el, progress, inStart, inEnd, outStart, outEnd)` to set
   `opacity`/`transform` directly — same reasoning, same reason it stays
   at 60fps.
6. Because everything is a pure function of `progressStore.value`,
   scrolling up reverses the whole film exactly — there's no separate
   "reverse" logic anywhere.

All scene boundaries live in one place, `TIMELINE` in
`src/utils/progressStore.js`, matching the brief's example breakpoints
(0.00 closed → 0.08 wrapper opens → 0.22 pad emerges → … → 1.00 final).

## 3. Where to replace the placeholder sanitary-pad model

Right now `SanitaryPad.jsx` builds every part (layers, wings, wrapper
flaps) from procedural `three.js` shapes in `src/utils/padShape.js`. To
swap in a real model:

1. Drop your file at `public/assets/sanitary-pad.glb`.
2. In `SanitaryPad.jsx`, load it with drei's `useGLTF`:
   ```js
   const { nodes } = useGLTF("/assets/sanitary-pad.glb");
   ```
3. Replace each procedural `<mesh>`/`<ProductLayer>` with the matching
   named node from the GLB (e.g. `nodes.TopSheet`, `nodes.AbsorbentCore`,
   `nodes.LeftWing`), keeping the same `ref`s and the same `useFrame`
   block that drives their `position`/`rotation`/`scale`/opacity — the
   animation logic doesn't change, only what's inside each `<mesh>`.
4. Keep `LAYER_CONFIG` (in `ProductLayers.jsx`) as the contract between
   the model and the on-canvas technical labels — its `key`/`label`/`sub`
   fields are what the `<Html>` labels in `SanitaryPad.jsx` render.

## 4. Where to replace textures/images

- `public/assets/wrapper.png`, `hero-product.jpg`, `core-texture.jpg` are
  referenced as placeholder paths in the brief; wire them in as
  `map`/`roughnessMap` textures on the relevant `meshPhysicalMaterial`s
  in `SanitaryPad.jsx` and `CoreVisualization.jsx` via drei's
  `useTexture("/assets/wrapper.png")`.
- If you'd rather ship no textures and stay fully procedural, no change
  needed — everything already runs without any files in `public/assets/`.

## 5. How to adjust animation timing

- Change the overall pace: edit `SPACER_VH` in `App.jsx` (more `vh` =
  slower, more deliberate scroll; less = snappier).
- Change where a scene starts/ends: edit the matching value in `TIMELINE`
  (`src/utils/progressStore.js`) — every component reads from this table,
  so one edit re-times the 3D animation, the text fade windows, and the
  progress indicator together.
- Change how "snappy" the scrub feels: the `scrub: 0.6` value in
  `useScrollTimeline.js` (higher = more lag/smoothing).
- Change per-part motion (e.g. how far a layer separates, how far a wing
  rotates): edit the relevant `mapRange`/`lerp` calls inside each
  component's `useFrame` (`SanitaryPad.jsx`, `CameraController.jsx`).

## 6. How to add the real HSN branding

- Colors: already centralized in `tailwind.config.js` (`hsn-black`,
  `hsn-green-deep`, `hsn-green-soft`, `hsn-white`, `hsn-gray`) and mirrored
  as CSS variables in `src/index.css` — change them there once.
- Typeface: currently Inter (loaded in `index.html`); swap the Google
  Fonts `<link>` and the `fontFamily.sans` entry in `tailwind.config.js`.
- Wordmark/nav copy: `Navigation.jsx` ("HSN" + section labels) and
  `IntroText.jsx` / `StoryText.jsx` (`brand` block: "HSN STUDIO" /
  "Human Solutions Network").
- Favicon/meta: `index.html` `<head>`.

## 7. How to deploy it

`npm run build` produces a static `dist/` folder — deploy it to any
static host (Vercel, Netlify, Cloudflare Pages, S3 + CloudFront, GitHub
Pages). No server/runtime is required. If deploying under a sub-path,
set Vite's `base` option in `vite.config.js` accordingly.

## Mobile / performance notes

- `App.jsx` detects touch + narrow viewports and passes `isMobile` down;
  `Particles` and `CoreVisualization` both roughly halve their instance
  counts on mobile, and `ProductScene` caps `devicePixelRatio` at `1.25`
  on mobile / `1.5` on desktop.
- Nothing pushes per-frame values into React state — all animation state
  lives in refs/mutable objects read inside `useFrame`, per the brief's
  performance requirements.
- If WebGL is genuinely too slow on a given device, the recommended next
  step (not yet implemented) is a feature check in `App.jsx` that swaps
  `<ProductScene>` for a pre-rendered image/video sequence scrubbed by the
  same `progressStore.value`.
