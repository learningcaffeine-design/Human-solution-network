Drop real assets here — the app runs fine without them:

- sanitary-pad.glb   — replaces the procedural pad (see project README, section 3)
- wrapper.png        — wrapper texture
- hero-product.jpg   — reference/marketing image
- core-texture.jpg   — absorbent-core texture
