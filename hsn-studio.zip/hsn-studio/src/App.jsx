import React, { useRef, useEffect, useState, useCallback } from "react";
import ProductScene from "./components/Experience/ProductScene";
import Navigation from "./components/UI/Navigation";
import ProgressIndicator from "./components/UI/ProgressIndicator";
import IntroText from "./components/UI/IntroText";
import StoryText from "./components/UI/StoryText";
import { useScrollTimeline } from "./hooks/useScrollTimeline";
import { TIMELINE, mapRange } from "./utils/progressStore";
import { SECTIONS } from "./sections";

// Total scroll distance (in viewport heights) that drives the entire
// cinematic timeline from experienceProgress 0 -> 1. Raise this to slow
// the whole story down; lower it to speed the story up. See README.
const SPACER_VH = 700;

/**
 * Imperatively fades + lifts a text block in/out of view for a window of
 * the master progress value, without touching React state — this is the
 * "UI text opacity/position" requirement from the brief, done via refs so
 * scrolling never triggers a React re-render of the whole tree.
 */
function fadeWindow(el, p, inStart, inEnd, outStart, outEnd, translate = 16) {
  if (!el) return;
  const fadeIn = mapRange(p, inStart, inEnd, 0, 1);
  const fadeOut = mapRange(p, outStart, outEnd, 0, 1);
  const opacity = Math.max(0, Math.min(fadeIn, 1 - fadeOut));
  el.style.opacity = opacity.toFixed(3);
  el.style.transform = `translateY(${((1 - opacity) * translate).toFixed(2)}px)`;
  el.style.pointerEvents = opacity > 0.05 ? "auto" : "none";
}

export default function App() {
  const spacerRef = useRef(null);
  const [isMobile, setIsMobile] = useState(false);

  const introRef = useRef(null);
  const revealRef = useRef(null);
  const productRef = useRef(null);
  const layersRef = useRef(null);
  const coreRef = useRef(null);
  const finalRef = useRef(null);
  const progressBarRef = useRef(null);
  const progressLabelRef = useRef(null);
  const navRef = useRef(null);

  useEffect(() => {
    const check = () =>
      setIsMobile(window.innerWidth < 768 || ("ontouchstart" in window && window.innerWidth < 1024));
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, []);

  const handleProgress = useCallback((p) => {
    const t = TIMELINE;

    fadeWindow(introRef.current, p, 0, 0.015, t.introEnd, t.wrapperOpenStart + 0.02);
    fadeWindow(
      revealRef.current,
      p,
      t.wrapperOpenStart + 0.01,
      t.wrapperOpenStart + 0.05,
      t.wrapperOpenEnd - 0.02,
      t.wrapperOpenEnd + 0.03
    );
    fadeWindow(
      productRef.current,
      p,
      t.padEmergeStart + 0.03,
      t.padEmergeStart + 0.09,
      t.padEmergeEnd,
      t.layersHoldEnd
    );
    fadeWindow(
      layersRef.current,
      p,
      t.layersHoldEnd - 0.01,
      t.layersHoldEnd + 0.03,
      t.explodeEnd - 0.08,
      t.explodeEnd - 0.02
    );
    fadeWindow(
      coreRef.current,
      p,
      t.coreDiveStart + 0.02,
      t.coreDiveStart + 0.09,
      t.coreDiveEnd - 0.02,
      t.coreDiveEnd + 0.05
    );
    fadeWindow(finalRef.current, p, t.finalStart, t.finalStart + 0.06, 1.001, 1.002, 10);

    if (progressBarRef.current) {
      progressBarRef.current.style.transform = `scaleY(${p})`;
    }
    if (progressLabelRef.current) {
      const step = Math.min(6, Math.max(1, Math.ceil(p * 6)));
      progressLabelRef.current.textContent = `0${step} / 06`;
    }
    if (navRef.current) {
      const navOpacity = p < 0.03 ? mapRange(p, 0, 0.03, 0, 1) : p > 0.96 ? mapRange(p, 0.96, 1, 1, 0) : 1;
      navRef.current.style.opacity = navOpacity.toFixed(3);
    }
  }, []);

  useScrollTimeline(spacerRef, handleProgress);

  const scrollToProgress = useCallback((target) => {
    const spacer = spacerRef.current;
    if (!spacer) return;
    const rect = spacer.getBoundingClientRect();
    const top = window.scrollY + rect.top;
    const scrollable = spacer.offsetHeight - window.innerHeight;
    window.scrollTo({ top: top + scrollable * target, behavior: "smooth" });
  }, []);

  return (
    <>
      <ProductScene isMobile={isMobile} />

      <div className="ui-layer">
        <Navigation ref={navRef} sections={SECTIONS} onNavigate={scrollToProgress} />
        <ProgressIndicator barRef={progressBarRef} labelRef={progressLabelRef} />

        <IntroText ref={introRef} />

        <StoryText ref={revealRef} lines={["LOOK CLOSER."]} />

        <StoryText
          ref={productRef}
          lines={["WHAT LOOKS SIMPLE", "IS BUILT AS A SYSTEM."]}
        />

        <StoryText ref={layersRef} lines={["DESIGNED IN LAYERS."]} compact />

        <StoryText
          ref={coreRef}
          lines={["THE CORE"]}
          support={["A SYSTEM DESIGNED", "TO MANAGE FLUID", "THROUGH MULTIPLE", "STRUCTURAL LAYERS."]}
        />

        <StoryText ref={finalRef} centered lines={["EVERYTHING", "HAS A SYSTEM."]} brand />
      </div>

      <div className="grain" />
      <div className="vignette" />

      {/* Tall spacer — its scroll distance is scrubbed into experienceProgress (0 -> 1) */}
      <div ref={spacerRef} style={{ height: `${SPACER_VH}vh` }} aria-hidden="true" />
    </>
  );
}
