import React, { useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { progressStore } from "../../utils/progressStore";

// Camera keyframes across the 0 -> 1 master timeline. Each has a position
// and a look-at target; we interpolate smoothly between the two keyframes
// surrounding the current progress value.
const KEYFRAMES = [
  { p: 0.0, pos: [0.3, 0.15, 5.2], look: [0, 0, 0], fov: 32 },
  { p: 0.08, pos: [0.5, 0.25, 4.4], look: [0, 0, 0], fov: 32 },
  { p: 0.22, pos: [1.0, 0.35, 3.6], look: [0, 0, 0], fov: 33 },
  { p: 0.38, pos: [0.15, 1.9, 2.7], look: [0, 0, 0], fov: 34 },
  { p: 0.46, pos: [0.05, 2.3, 1.9], look: [0, 0, 0], fov: 35 },
  { p: 0.62, pos: [0.9, 1.1, 2.6], look: [0, 0, 0], fov: 33 },
  { p: 0.78, pos: [0.12, 0.35, 0.85], look: [0, 0, 0], fov: 40 },
  { p: 0.9, pos: [0.0, 1.6, 3.1], look: [0, 0, 0], fov: 32 },
  { p: 1.0, pos: [0.0, 0.35, 3.6], look: [0, 0, 0], fov: 30 },
];

function findSegment(p) {
  for (let i = 0; i < KEYFRAMES.length - 1; i++) {
    if (p >= KEYFRAMES[i].p && p <= KEYFRAMES[i + 1].p) {
      const a = KEYFRAMES[i];
      const b = KEYFRAMES[i + 1];
      const local = (p - a.p) / (b.p - a.p || 1);
      // smoothstep for a more cinematic ease than linear
      const eased = local * local * (3 - 2 * local);
      return { a, b, t: eased };
    }
  }
  const last = KEYFRAMES[KEYFRAMES.length - 1];
  return { a: last, b: last, t: 0 };
}

export default function CameraController() {
  const { camera, pointer } = useThree();
  const tmpPos = useRef(new THREE.Vector3());
  const tmpLook = useRef(new THREE.Vector3());
  const currentLook = useRef(new THREE.Vector3(0, 0, 0));
  const parallax = useRef(new THREE.Vector2(0, 0));

  useFrame((_, delta) => {
    const p = progressStore.value;
    const { a, b, t } = findSegment(p);

    tmpPos.current.set(
      THREE.MathUtils.lerp(a.pos[0], b.pos[0], t),
      THREE.MathUtils.lerp(a.pos[1], b.pos[1], t),
      THREE.MathUtils.lerp(a.pos[2], b.pos[2], t)
    );
    tmpLook.current.set(
      THREE.MathUtils.lerp(a.look[0], b.look[0], t),
      THREE.MathUtils.lerp(a.look[1], b.look[1], t),
      THREE.MathUtils.lerp(a.look[2], b.look[2], t)
    );

    // extremely subtle mouse parallax — a few pixels' worth of world units
    parallax.current.x = THREE.MathUtils.damp(parallax.current.x, pointer.x * 0.06, 4, delta);
    parallax.current.y = THREE.MathUtils.damp(parallax.current.y, pointer.y * 0.035, 4, delta);

    camera.position.x = THREE.MathUtils.damp(
      camera.position.x,
      tmpPos.current.x + parallax.current.x,
      3.5,
      delta
    );
    camera.position.y = THREE.MathUtils.damp(
      camera.position.y,
      tmpPos.current.y + parallax.current.y,
      3.5,
      delta
    );
    camera.position.z = THREE.MathUtils.damp(camera.position.z, tmpPos.current.z, 3.5, delta);

    currentLook.current.lerp(tmpLook.current, Math.min(1, delta * 3.5));
    camera.lookAt(currentLook.current);

    const targetFov = THREE.MathUtils.lerp(a.fov, b.fov, t);
    if (camera.fov !== targetFov) {
      camera.fov = THREE.MathUtils.damp(camera.fov, targetFov, 3, delta);
      camera.updateProjectionMatrix();
    }
  });

  return null;
}
