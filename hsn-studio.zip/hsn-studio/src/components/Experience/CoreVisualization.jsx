import React, { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { progressStore, mapRange, TIMELINE } from "../../utils/progressStore";

const FIBER_COUNT_DESKTOP = 140;
const FIBER_COUNT_MOBILE = 60;
const FLUID_COUNT_DESKTOP = 260;
const FLUID_COUNT_MOBILE = 100;

/**
 * A non-graphic, abstract representation of the absorbent core: scattered
 * thin fibers plus soft drifting particles standing in for fluid movement.
 * Visible only during the SCENE 05 core dive, driven entirely by progress.
 */
export default function CoreVisualization({ isMobile = false }) {
  const fiberCount = isMobile ? FIBER_COUNT_MOBILE : FIBER_COUNT_DESKTOP;
  const fluidCount = isMobile ? FLUID_COUNT_MOBILE : FLUID_COUNT_DESKTOP;

  const fibersRef = useRef();
  const fluidRef = useRef();
  const dummy = useMemo(() => new THREE.Object3D(), []);

  const fiberGeometry = useMemo(() => new THREE.CapsuleGeometry(0.006, 0.16, 2, 4), []);
  const fiberTransforms = useMemo(() => {
    return new Array(fiberCount).fill(0).map(() => ({
      pos: new THREE.Vector3(
        (Math.random() - 0.5) * 0.55,
        (Math.random() - 0.5) * 0.35,
        (Math.random() - 0.5) * 0.55
      ),
      rot: new THREE.Euler(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI),
      seed: Math.random() * Math.PI * 2,
    }));
  }, [fiberCount]);

  const { fluidPositions, fluidSeeds } = useMemo(() => {
    const fluidPositions = new Float32Array(fluidCount * 3);
    const fluidSeeds = new Float32Array(fluidCount);
    for (let i = 0; i < fluidCount; i++) {
      fluidPositions[i * 3] = (Math.random() - 0.5) * 0.6;
      fluidPositions[i * 3 + 1] = (Math.random() - 0.5) * 0.4;
      fluidPositions[i * 3 + 2] = (Math.random() - 0.5) * 0.6;
      fluidSeeds[i] = Math.random() * Math.PI * 2;
    }
    return { fluidPositions, fluidSeeds };
  }, [fluidCount]);

  useFrame((state, delta) => {
    const p = progressStore.value;
    const visibility = mapRange(p, TIMELINE.coreDiveStart, TIMELINE.coreDiveEnd, 0, 1);
    const fadeOut = 1 - mapRange(p, TIMELINE.reconstructStart, TIMELINE.reconstructEnd, 0, 1);
    const amt = visibility * fadeOut;

    if (fibersRef.current) {
      fibersRef.current.visible = amt > 0.01;
      fiberTransforms.forEach((f, i) => {
        dummy.position.copy(f.pos);
        dummy.rotation.copy(f.rot);
        const wobble = Math.sin(state.clock.elapsedTime * 0.6 + f.seed) * 0.01;
        dummy.position.y += wobble;
        dummy.scale.setScalar(amt);
        dummy.updateMatrix();
        fibersRef.current.setMatrixAt(i, dummy.matrix);
      });
      fibersRef.current.instanceMatrix.needsUpdate = true;
      fibersRef.current.material.opacity = THREE.MathUtils.damp(
        fibersRef.current.material.opacity,
        amt * 0.75,
        4,
        delta
      );
    }

    if (fluidRef.current) {
      fluidRef.current.visible = amt > 0.01;
      fluidRef.current.material.opacity = THREE.MathUtils.damp(
        fluidRef.current.material.opacity,
        amt * 0.55,
        4,
        delta
      );
      const array = fluidRef.current.geometry.attributes.position.array;
      for (let i = 0; i < fluidCount; i++) {
        array[i * 3 + 1] += Math.sin(state.clock.elapsedTime * 0.5 + fluidSeeds[i]) * 0.0006;
        array[i * 3] += Math.cos(state.clock.elapsedTime * 0.3 + fluidSeeds[i]) * 0.0003;
      }
      fluidRef.current.geometry.attributes.position.needsUpdate = true;
    }
  });

  return (
    <group position={[0, 0, 0]}>
      <instancedMesh ref={fibersRef} args={[fiberGeometry, undefined, fiberCount]}>
        <meshStandardMaterial color="#DCE3DF" transparent opacity={0} roughness={0.4} />
      </instancedMesh>
      <points ref={fluidRef}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[fluidPositions, 3]} />
        </bufferGeometry>
        <pointsMaterial
          size={0.012}
          color="#9fd4c7"
          transparent
          opacity={0}
          depthWrite={false}
          sizeAttenuation
        />
      </points>
    </group>
  );
}
