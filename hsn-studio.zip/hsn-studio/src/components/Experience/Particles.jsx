import React, { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { progressStore, mapRange, TIMELINE } from "../../utils/progressStore";

/**
 * Ambient atmospheric particles. Kept extremely subtle per the brief —
 * this is haze, not a "particle effect". Count is halved on touch/mobile
 * devices to protect frame rate (see App.jsx isMobile detection).
 */
export default function Particles({ count = 900, isMobile = false }) {
  const total = isMobile ? Math.floor(count * 0.4) : count;
  const pointsRef = useRef();

  const { positions, seeds } = useMemo(() => {
    const positions = new Float32Array(total * 3);
    const seeds = new Float32Array(total);
    for (let i = 0; i < total; i++) {
      const radius = 3 + Math.random() * 6;
      const theta = Math.random() * Math.PI * 2;
      const y = (Math.random() - 0.5) * 6;
      positions[i * 3] = Math.cos(theta) * radius;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = Math.sin(theta) * radius;
      seeds[i] = Math.random() * Math.PI * 2;
    }
    return { positions, seeds };
  }, [total]);

  useFrame((state, delta) => {
    if (!pointsRef.current) return;
    const p = progressStore.value;
    pointsRef.current.rotation.y += delta * 0.008;

    // particles become extremely subtle by the final scene
    const mat = pointsRef.current.material;
    const finalFade = 1 - mapRange(p, TIMELINE.finalStart, TIMELINE.finalEnd, 0, 0.6);
    mat.opacity = THREE.MathUtils.damp(mat.opacity, 0.35 * finalFade, 3, delta);

    const array = pointsRef.current.geometry.attributes.position.array;
    for (let i = 0; i < total; i++) {
      array[i * 3 + 1] += Math.sin(state.clock.elapsedTime * 0.15 + seeds[i]) * 0.0003;
    }
    pointsRef.current.geometry.attributes.position.needsUpdate = true;
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial
        size={0.018}
        color="#BFDCCF"
        transparent
        opacity={0.35}
        depthWrite={false}
        sizeAttenuation
      />
    </points>
  );
}
