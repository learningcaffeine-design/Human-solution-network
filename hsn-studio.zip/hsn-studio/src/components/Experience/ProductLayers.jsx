import React, { useMemo } from "react";
import * as THREE from "three";
import { createLayerOutline } from "../../utils/padShape";

// The five conceptual layers from the brief. `explodeOffset` is the target
// Y-axis separation (world units) at full exploded view. Colors stay inside
// the HSN palette — white/soft-green/muted-gray — with opacity used to read
// as material rather than as flat brand color.
export const LAYER_CONFIG = [
  {
    key: "topSheet",
    label: "TOP SHEET",
    sub: "Comfort + fluid transfer",
    color: "#F5F7F5",
    opacity: 0.92,
    depth: 0.018,
    inset: 0,
    explodeOffset: 0.8,
  },
  {
    key: "acquisition",
    label: "ACQUISITION LAYER",
    sub: "Distributes fluid",
    color: "#BFDCCF",
    opacity: 0.42,
    depth: 0.022,
    inset: 0.05,
    explodeOffset: 0.4,
  },
  {
    key: "core",
    label: "ABSORBENT CORE",
    sub: "Captures and retains",
    color: "#8FB79F",
    opacity: 0.95,
    depth: 0.055,
    inset: 0.1,
    explodeOffset: 0,
  },
  {
    key: "barrier",
    label: "PROTECTIVE BARRIER",
    sub: "Helps prevent leakage",
    color: "#9CA8A3",
    opacity: 0.4,
    depth: 0.018,
    inset: 0.05,
    explodeOffset: -0.4,
  },
  {
    key: "backing",
    label: "BACKING LAYER",
    sub: "Provides structural protection",
    color: "#DCE3DF",
    opacity: 0.88,
    depth: 0.02,
    inset: 0,
    explodeOffset: -0.8,
  },
];

/**
 * A single extruded layer mesh. Position.y is driven imperatively by the
 * parent (SanitaryPad) via a ref each frame — see explodeOffset usage there.
 */
export const ProductLayer = React.forwardRef(function ProductLayer(
  { config, length, width },
  ref
) {
  const geometry = useMemo(() => {
    const shape = createLayerOutline(length, width, config.inset);
    const geo = new THREE.ExtrudeGeometry(shape, {
      depth: config.depth,
      bevelEnabled: true,
      bevelThickness: 0.006,
      bevelSize: 0.006,
      bevelSegments: 2,
      curveSegments: 24,
    });
    geo.rotateX(-Math.PI / 2);
    geo.translate(0, 0, 0);
    return geo;
  }, [length, width, config.inset, config.depth]);

  return (
    <mesh ref={ref} geometry={geometry} castShadow receiveShadow>
      <meshPhysicalMaterial
        color={config.color}
        transparent
        opacity={config.opacity}
        roughness={0.55}
        clearcoat={0.15}
        transmission={config.key === "acquisition" || config.key === "barrier" ? 0.35 : 0}
        thickness={0.1}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
});
