import React from "react";
import { Canvas } from "@react-three/fiber";
import SanitaryPad from "./SanitaryPad";
import CameraController from "./CameraController";
import Particles from "./Particles";
import CoreVisualization from "./CoreVisualization";

export default function ProductScene({ isMobile }) {
  return (
    <Canvas
      className="canvas-layer"
      dpr={[1, isMobile ? 1.25 : 1.5]}
      gl={{ antialias: true, powerPreference: "high-performance" }}
      camera={{ position: [0.3, 0.15, 5.2], fov: 32, near: 0.05, far: 40 }}
    >
      <color attach="background" args={["#050807"]} />
      <fog attach="fog" args={["#050807", 3.2, 9]} />

      <ambientLight intensity={0.35} color="#BFDCCF" />
      <directionalLight
        position={[2.2, 3.2, 2.4]}
        intensity={1.4}
        color="#F5F7F5"
        castShadow={false}
      />
      <pointLight position={[-2, -1, -1.5]} intensity={0.5} color="#0B241D" />
      <pointLight position={[0, 0.4, 1.2]} intensity={0.6} color="#BFDCCF" />

      <CameraController />
      <SanitaryPad />
      <CoreVisualization isMobile={isMobile} />
      <Particles isMobile={isMobile} />
    </Canvas>
  );
}
