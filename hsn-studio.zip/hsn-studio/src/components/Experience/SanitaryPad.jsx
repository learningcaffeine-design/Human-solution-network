import React, { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { Html } from "@react-three/drei";
import * as THREE from "three";
import { LAYER_CONFIG, ProductLayer } from "./ProductLayers";
import { createWingShape, createWrapperFlapShape } from "../../utils/padShape";
import { progressStore, mapRange, TIMELINE } from "../../utils/progressStore";

const PAD_LENGTH = 2.6;
const PAD_WIDTH = 0.78;

/**
 * <SanitaryPad>
 *   <TopSheet /> <AcquisitionLayer /> <AbsorbentCore /> <BarrierLayer /> <BackingLayer />
 *   <LeftWing /> <RightWing />
 * </SanitaryPad>
 *
 * The brief asks for this modular structure so the procedural placeholder
 * below can later be swapped for a real GLB. To do that:
 *   1. Load the model with useGLTF("/assets/sanitary-pad.glb")
 *   2. Replace the <ProductLayer> meshes with named nodes from the GLB
 *      (e.g. nodes.TopSheet, nodes.AbsorbentCore, ...) while keeping the
 *      same refs + useFrame driven transforms below.
 *   3. Keep LAYER_CONFIG's explodeOffset/label values as the contract
 *      between the 3D model and the UI labels in StoryText.jsx.
 */
export default function SanitaryPad() {
  const rootRef = useRef();
  const wrapperLeftRef = useRef();
  const wrapperRightRef = useRef();
  const wingLeftRef = useRef();
  const wingRightRef = useRef();
  const layerGroupRefs = useRef(LAYER_CONFIG.map(() => React.createRef()));
  const labelRefs = useRef(LAYER_CONFIG.map(() => React.createRef()));
  const clock = useRef(0);

  const wrapperShape = useMemo(
    () => createWrapperFlapShape(PAD_WIDTH * 0.62, PAD_LENGTH * 0.86, 0.09),
    []
  );
  const wingShape = useMemo(() => createWingShape(0.3), []);

  useFrame((_, delta) => {
    clock.current += delta;
    const p = progressStore.value;
    const t = TIMELINE;

    // ---- idle cinematic float (fades out as the story gets technical) ----
    const floatAmt = mapRange(p, 0, 0.3, 1, 0.25);
    if (rootRef.current) {
      rootRef.current.rotation.y = Math.sin(clock.current * 0.25) * 0.12 * floatAmt + p * 0.35;
      rootRef.current.position.y = Math.sin(clock.current * 0.4) * 0.03 * floatAmt;

      const revealScale = THREE.MathUtils.lerp(0.62, 1, mapRange(p, 0, t.padEmergeEnd, 0, 1));
      const finalScale = THREE.MathUtils.lerp(
        revealScale,
        0.92,
        mapRange(p, t.finalStart, t.finalEnd, 0, 1)
      );
      rootRef.current.scale.setScalar(finalScale);
    }

    // ---- wrapper opening (early) + returning (reconstruction) ----
    const openEarly = mapRange(p, t.wrapperOpenStart, t.wrapperOpenEnd, 0, 1);
    const wrapperReturn = mapRange(p, t.reconstructStart, t.reconstructEnd, 0, 1);
    const wrapperFactor = openEarly * (1 - wrapperReturn);
    if (wrapperLeftRef.current && wrapperRightRef.current) {
      wrapperLeftRef.current.rotation.y = THREE.MathUtils.damp(
        wrapperLeftRef.current.rotation.y,
        THREE.MathUtils.lerp(0, -2.5, wrapperFactor),
        4,
        delta
      );
      wrapperRightRef.current.rotation.y = THREE.MathUtils.damp(
        wrapperRightRef.current.rotation.y,
        THREE.MathUtils.lerp(0, 2.5, wrapperFactor),
        4,
        delta
      );
    }

    // ---- wings unfolding with the pad, folding back during reconstruction ----
    const wingOpenEarly = mapRange(p, t.padEmergeStart, t.padEmergeEnd, 0, 1);
    const wingFactor = wingOpenEarly * (1 - wrapperReturn);
    if (wingLeftRef.current && wingRightRef.current) {
      wingLeftRef.current.rotation.y = THREE.MathUtils.damp(
        wingLeftRef.current.rotation.y,
        THREE.MathUtils.lerp(-1.9, 0, wingFactor),
        4,
        delta
      );
      wingRightRef.current.rotation.y = THREE.MathUtils.damp(
        wingRightRef.current.rotation.y,
        THREE.MathUtils.lerp(1.9, 0, wingFactor),
        4,
        delta
      );
    }

    // ---- exploded layer view, reconstructing near the end ----
    const explodeEarly = mapRange(p, t.explodeStart, t.explodeEnd, 0, 1);
    const explodeFactor = explodeEarly * (1 - wrapperReturn);
    // during the core dive, gently push non-core layers further out of focus
    const coreDive = mapRange(p, t.coreDiveStart, t.coreDiveEnd, 0, 1);

    LAYER_CONFIG.forEach((cfg, i) => {
      const group = layerGroupRefs.current[i].current;
      if (!group) return;
      const targetY = cfg.explodeOffset * explodeFactor * (1 + coreDive * 0.35);
      group.position.y = THREE.MathUtils.damp(group.position.y, targetY, 4, delta);

      // fade non-core layers as we dive into the core
      const mat = group.children[0]?.material;
      if (mat) {
        const isCore = cfg.key === "core";
        const targetOpacity = isCore
          ? cfg.opacity
          : cfg.opacity * (1 - coreDive * 0.85);
        mat.opacity = THREE.MathUtils.damp(mat.opacity, targetOpacity, 3, delta);
      }

      // technical labels fade in with the exploded view, fade out on the core dive
      const labelEl = labelRefs.current[i].current;
      if (labelEl) {
        const labelOpacity = Math.max(0, explodeFactor - coreDive * 1.1);
        labelEl.style.opacity = labelOpacity.toFixed(3);
      }
    });
  });

  return (
    <group ref={rootRef}>
      {/* Layers stack: rendered flat, separated on the Y axis in useFrame */}
      {LAYER_CONFIG.map((cfg, i) => (
        <group key={cfg.key} ref={layerGroupRefs.current[i]}>
          <ProductLayer config={cfg} length={PAD_LENGTH} width={PAD_WIDTH} />
          <Html position={[PAD_WIDTH / 2 + 0.5, 0, 0]} center={false} zIndexRange={[20, 0]}>
            <div
              ref={labelRefs.current[i]}
              className="whitespace-nowrap text-hsn-white"
              style={{ opacity: 0, transition: "opacity 0.1s linear" }}
            >
              <div className="text-[11px] tracked-sm font-normal">{cfg.label}</div>
              <div className="text-[10px] text-hsn-gray font-light mt-0.5">{cfg.sub}</div>
            </div>
          </Html>
        </group>
      ))}

      {/* Wings — hinged flaps that fold flat against the body when closed */}
      <group position={[PAD_WIDTH / 2, 0.05, 0]} ref={wingRightRef}>
        <mesh rotation={[-Math.PI / 2, 0, 0]}>
          <shapeGeometry args={[wingShape]} />
          <meshPhysicalMaterial color="#F5F7F5" roughness={0.6} side={THREE.DoubleSide} />
        </mesh>
      </group>
      <group position={[-PAD_WIDTH / 2, 0.05, 0]} ref={wingLeftRef} scale={[-1, 1, 1]}>
        <mesh rotation={[-Math.PI / 2, 0, 0]}>
          <shapeGeometry args={[wingShape]} />
          <meshPhysicalMaterial color="#F5F7F5" roughness={0.6} side={THREE.DoubleSide} />
        </mesh>
      </group>

      {/* Wrapper flaps — cover the pad at rest, swing open on scroll */}
      <group position={[PAD_WIDTH * 0.31, 0.08, 0]} ref={wrapperRightRef}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[PAD_WIDTH * 0.31, 0, 0]}>
          <shapeGeometry args={[wrapperShape]} />
          <meshPhysicalMaterial
            color="#0B241D"
            roughness={0.35}
            metalness={0.1}
            clearcoat={0.4}
            side={THREE.DoubleSide}
          />
        </mesh>
      </group>
      <group position={[-PAD_WIDTH * 0.31, 0.08, 0]} ref={wrapperLeftRef}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[-PAD_WIDTH * 0.31, 0, 0]}>
          <shapeGeometry args={[wrapperShape]} />
          <meshPhysicalMaterial
            color="#0B241D"
            roughness={0.35}
            metalness={0.1}
            clearcoat={0.4}
            side={THREE.DoubleSide}
          />
        </mesh>
      </group>
    </group>
  );
}
