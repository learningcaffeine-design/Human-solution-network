import React, { forwardRef } from "react";

/**
 * Scene 01 (INTRO) text block. Opacity/position are driven imperatively
 * by App.jsx via the forwarded ref — this component only lays out markup.
 */
const IntroText = forwardRef(function IntroText(_, ref) {
  return (
    <div
      ref={ref}
      className="story-block left-[6%] bottom-[10%] sm:left-[8%] sm:bottom-[14%] max-w-[520px]"
    >
      <h1 className="text-2xl sm:text-3xl md:text-4xl font-extralight leading-[1.25] text-hsn-white tracked-sm">
        EVERY PRODUCT
        <br />
        HAS A SYSTEM
        <br />
        BEHIND IT.
      </h1>
      <div className="mt-5 h-px w-10 bg-hsn-green-soft/50" />
      <p className="mt-3 text-[11px] tracked text-hsn-gray font-light">HSN STUDIO</p>

      <div className="hidden sm:flex items-center gap-3 absolute -right-24 bottom-1 text-hsn-gray">
        <span className="text-[10px] tracked-sm rotate-90 origin-left translate-x-2">SCROLL</span>
        <span className="relative block h-14 w-px bg-hsn-gray/30 overflow-hidden">
          <span className="absolute inset-x-0 top-0 h-4 w-px bg-hsn-green-soft animate-scrollcue" />
        </span>
      </div>
    </div>
  );
});

export default IntroText;
