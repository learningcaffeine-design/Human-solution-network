import React, { forwardRef } from "react";

/**
 * Extremely minimal top bar. Deliberately not a normal navbar: no
 * background chrome, no menu icon, just a wordmark and three quiet
 * text links that scrub the scroll position to a scene's progress value.
 * Opacity is driven imperatively by App.jsx (fades near the very start
 * and very end of the experience so it never competes with the intro
 * or the closing message).
 */
const Navigation = forwardRef(function Navigation({ sections, onNavigate }, ref) {
  const links = sections.filter((s) => s.navLabel);

  return (
    <div
      ref={ref}
      className="fixed top-0 inset-x-0 z-30 flex items-center justify-between px-6 sm:px-10 py-6 pointer-events-none"
      style={{ paddingTop: "max(1.5rem, env(safe-area-inset-top, 0px))" }}
    >
      <span className="text-sm tracked text-hsn-white font-light pointer-events-auto">HSN</span>
      <nav className="hidden sm:flex items-center gap-8 pointer-events-auto">
        {links.map((section) => (
          <button
            key={section.id}
            type="button"
            onClick={() => onNavigate(section.progress)}
            className="text-[11px] tracked-sm text-hsn-gray hover:text-hsn-white transition-colors duration-300 font-light"
          >
            {section.navLabel}
          </button>
        ))}
      </nav>
    </div>
  );
});

export default Navigation;
