import React from "react";

/**
 * Small vertical progress line + "0X / 06" counter, bottom-right.
 * Both barRef (the fill) and labelRef (the text) are updated imperatively
 * by App.jsx on every scroll tick — no React state involved.
 */
export default function ProgressIndicator({ barRef, labelRef }) {
  return (
    <div className="hidden md:flex flex-col items-center gap-3 fixed right-8 bottom-10 z-30">
      <span
        ref={labelRef}
        className="text-[10px] tracked-sm text-hsn-gray font-light"
      >
        01 / 06
      </span>
      <div className="relative h-24 w-px bg-hsn-white/15 overflow-hidden">
        <div
          ref={barRef}
          className="absolute inset-x-0 bottom-0 top-0 origin-bottom bg-hsn-green-soft"
          style={{ transform: "scaleY(0)" }}
        />
      </div>
    </div>
  );
}
