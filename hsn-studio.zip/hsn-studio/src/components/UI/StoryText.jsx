import React, { forwardRef } from "react";

/**
 * Generic narrative text block used for every scene after the intro.
 * Only one of these is ever meaningfully opaque at a time — App.jsx's
 * fadeWindow() enforces non-overlapping visibility windows per the
 * brief's "only one text block should be visible at a time" rule.
 *
 * Props:
 *  - lines: string[]        primary headline lines
 *  - support: string[]      optional smaller supporting lines (Scene 05)
 *  - compact: bool          smaller type for brief single-line beats
 *  - centered: bool         center-stage placement (used for the finale)
 *  - brand: bool            append "HSN STUDIO / Human Solutions Network"
 */
const StoryText = forwardRef(function StoryText(
  { lines = [], support = [], compact = false, centered = false, brand = false },
  ref
) {
  if (centered) {
    return (
      <div
        ref={ref}
        className="story-block left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-center w-full max-w-xl px-6"
      >
        <h2 className="text-4xl sm:text-5xl md:text-6xl font-extralight leading-[1.15] text-hsn-white tracked-sm">
          {lines.map((line, i) => (
            <span key={i} className="block">
              {line}
            </span>
          ))}
        </h2>
        {brand && (
          <div className="mt-8 flex flex-col items-center gap-2">
            <div className="h-px w-10 bg-hsn-green-soft/50" />
            <p className="text-sm tracked text-hsn-green-soft font-light">HSN STUDIO</p>
            <p className="text-[11px] tracked-sm text-hsn-gray font-light">
              Human Solutions Network
            </p>
          </div>
        )}
      </div>
    );
  }

  return (
    <div
      ref={ref}
      className={`story-block left-[6%] sm:left-[8%] bottom-[12%] sm:bottom-[16%] max-w-[460px] ${
        compact ? "max-w-[320px]" : ""
      }`}
    >
      <p
        className={`font-extralight text-hsn-white tracked-sm leading-[1.35] ${
          compact ? "text-lg sm:text-xl" : "text-xl sm:text-2xl md:text-3xl"
        }`}
      >
        {lines.map((line, i) => (
          <span key={i} className="block">
            {line}
          </span>
        ))}
      </p>
      {support.length > 0 && (
        <p className="mt-4 text-[12px] sm:text-[13px] tracked-sm text-hsn-gray font-light leading-[1.7] max-w-[280px]">
          {support.map((line, i) => (
            <span key={i} className="block">
              {line}
            </span>
          ))}
        </p>
      )}
    </div>
  );
});

export default StoryText;
