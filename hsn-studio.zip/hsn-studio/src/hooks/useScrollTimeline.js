import { useEffect } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { progressStore } from "../utils/progressStore";

gsap.registerPlugin(ScrollTrigger);

/**
 * Ties window scroll position (against a tall spacer element) to the
 * master experienceProgress value (0 -> 1). The 3D canvas and UI text
 * layers are position:fixed, so we don't need ScrollTrigger's `pin` —
 * we only need scroll distance to scrub the timeline.
 *
 * `onProgress` fires on every scrub tick and is used by the UI layer to
 * imperatively set text/opacity via refs (see App.jsx) rather than
 * through React state, to avoid re-rendering the tree every frame.
 */
export function useScrollTimeline(spacerRef, onProgress) {
  useEffect(() => {
    if (!spacerRef.current) return undefined;

    const trigger = ScrollTrigger.create({
      trigger: spacerRef.current,
      start: "top top",
      end: "bottom bottom",
      scrub: 0.6,
      onUpdate: (self) => {
        const prevValue = progressStore.value;
        progressStore.value = self.progress;
        progressStore.velocity = self.progress - prevValue;
        onProgress?.(self.progress);
      },
    });

    // Ensure the intro text/UI paint correctly before the user has
    // scrolled at all (ScrollTrigger's onUpdate only fires on scroll).
    progressStore.value = trigger.progress;
    onProgress?.(trigger.progress);

    return () => {
      trigger.kill();
    };
  }, [spacerRef, onProgress]);
}
