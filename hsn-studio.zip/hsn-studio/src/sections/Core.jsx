// Scene 05 — CAMERA INTO THE CORE. The most cinematic beat.
import { TIMELINE } from "../utils/progressStore";

export const Core = {
  id: "core",
  navLabel: null,
  progress: TIMELINE.coreDiveStart,
  description: "Camera dives into the absorbent core's fiber structure.",
};

export default Core;
