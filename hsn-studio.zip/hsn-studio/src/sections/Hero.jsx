// Scene 01 — INTRO. Metadata only: this experience is one continuous
// scroll-driven canvas (see App.jsx + ProductScene), so "sections" are
// timeline waypoints rather than routed/mounted components. Each file
// here documents one beat of the story and exposes the progress value
// navigation + the progress indicator use to reference it.
import { TIMELINE } from "../utils/progressStore";

export const Hero = {
  id: "hero",
  navLabel: null, // not shown in nav — this is the resting state
  progress: 0,
  description: "Closed package, mysterious, floating center-stage.",
};

export default Hero;
