// Scene 04 — EXPLODED VIEW. The five structural layers.
import { TIMELINE } from "../utils/progressStore";

export const Layers = {
  id: "layers",
  navLabel: "SYSTEMS",
  progress: TIMELINE.explodeStart,
  description: "Top sheet, acquisition layer, core, barrier, backing.",
};

export default Layers;
