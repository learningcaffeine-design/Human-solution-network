// Scenes 06–07 — RECONSTRUCTION + FINAL MESSAGE.
import { TIMELINE } from "../utils/progressStore";

export const Reconstruction = {
  id: "reconstruction",
  navLabel: "IMPACT",
  progress: TIMELINE.reconstructStart,
  description: "Layers reassemble; the film closes on the brand line.",
};

export default Reconstruction;
