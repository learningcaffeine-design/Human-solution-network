// Scenes 02–03 — PACKAGE OPENING + PRODUCT REVEAL.
import { TIMELINE } from "../utils/progressStore";

export const Reveal = {
  id: "reveal",
  navLabel: "ABOUT",
  progress: TIMELINE.wrapperOpenStart,
  description: "Wrapper opens, the pad emerges and unfolds.",
};

export default Reveal;
