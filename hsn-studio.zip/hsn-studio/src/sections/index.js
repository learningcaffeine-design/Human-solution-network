// Aggregates every scene waypoint into one ordered list, used by
// Navigation.jsx (click a nav label -> scroll to that scene's progress)
// and available for ProgressIndicator or future routed variants.
import Hero from "./Hero";
import Reveal from "./Reveal";
import Layers from "./Layers";
import Core from "./Core";
import Reconstruction from "./Reconstruction";

export const SECTIONS = [Hero, Reveal, Layers, Core, Reconstruction];
export { Hero, Reveal, Layers, Core, Reconstruction };
