import * as THREE from "three";

/**
 * Body silhouette: a long rounded lozenge (no wings baked in — wings are
 * separate hinged meshes so they can rotate open independently, see
 * SanitaryPad.jsx). This is a deliberately simple procedural placeholder.
 * Swap for geometry parsed from /public/assets/sanitary-pad.glb when ready.
 */
export function createPadOutline(length = 2.6, width = 0.78) {
  const shape = new THREE.Shape();
  const hw = width / 2;
  const hl = length / 2;

  shape.moveTo(0, hl);
  shape.quadraticCurveTo(hw * 1.08, hl * 0.98, hw, hl * 0.55);
  shape.lineTo(hw, -hl * 0.55);
  shape.quadraticCurveTo(hw * 1.08, -hl * 0.98, 0, -hl);
  shape.quadraticCurveTo(-hw * 1.08, -hl * 0.98, -hw, -hl * 0.55);
  shape.lineTo(-hw, hl * 0.55);
  shape.quadraticCurveTo(-hw * 1.08, hl * 0.98, 0, hl);

  return shape;
}

/** Smaller inset outline so stacked layers read distinctly without z-fighting. */
export function createLayerOutline(length, width, inset = 0) {
  return createPadOutline(Math.max(0.1, length - inset), Math.max(0.1, width - inset));
}

/** A single wing lobe, hinged at its inner (straight) edge — mirror with scale.x=-1 for the other side. */
export function createWingShape(size = 0.34) {
  const shape = new THREE.Shape();
  shape.moveTo(0, size * 0.62);
  shape.quadraticCurveTo(size * 0.9, size * 0.55, size * 1.05, 0);
  shape.quadraticCurveTo(size * 0.9, -size * 0.55, 0, -size * 0.62);
  shape.lineTo(0, size * 0.62);
  return shape;
}

/** Rounded-rect wrapper flap. */
export function createWrapperFlapShape(w, h, radius = 0.1) {
  const shape = new THREE.Shape();
  const x = -w / 2;
  const y = -h / 2;
  shape.moveTo(x, y + radius);
  shape.lineTo(x, y + h - radius);
  shape.quadraticCurveTo(x, y + h, x + radius, y + h);
  shape.lineTo(x + w - radius, y + h);
  shape.quadraticCurveTo(x + w, y + h, x + w, y + h - radius);
  shape.lineTo(x + w, y + radius);
  shape.quadraticCurveTo(x + w, y, x + w - radius, y);
  shape.lineTo(x + radius, y);
  shape.quadraticCurveTo(x, y, x, y + radius);
  return shape;
}
