// A tiny external mutable store for the master scroll timeline.
//
// Why not React state? The brief requires 60fps scroll-driven animation.
// If we pushed `progress` into React state on every scroll tick, every
// frame would re-render the whole component tree. Instead we keep a
// single mutable object that:
//   - GSAP's ScrollTrigger writes to directly (onUpdate)
//   - three.js/R3F components read every frame inside useFrame (no re-render)
//   - DOM/UI text blocks are updated imperatively via gsap.set from the
//     same onUpdate callback (see useScrollTimeline.js)
//
// experienceProgress (0 -> 1) is the single source of truth described
// in the brief. Everything else derives from it.

export const progressStore = {
  value: 0, // experienceProgress, 0 -> 1
  velocity: 0, // signed rate of change, useful for subtle motion blur / easing
};

/**
 * Remaps a value from one range to another, clamped by default.
 * Used everywhere to derive per-scene animation values from the master progress.
 */
export function mapRange(value, inMin, inMax, outMin, outMax, clampResult = true) {
  const t = (value - inMin) / (inMax - inMin);
  const result = outMin + t * (outMax - outMin);
  if (!clampResult) return result;
  const min = Math.min(outMin, outMax);
  const max = Math.max(outMin, outMax);
  return Math.min(max, Math.max(min, result));
}

// Master timeline breakpoints (0 -> 1). Adjust these to change pacing —
// every scene in the app reads from this single table.
export const TIMELINE = {
  introEnd: 0.08, // 0.00 - 0.08 closed package, mysterious
  wrapperOpenStart: 0.08,
  wrapperOpenEnd: 0.22, // wrapper flaps open
  padEmergeStart: 0.22,
  padEmergeEnd: 0.38, // pad slides out, wings unfold
  layersHoldEnd: 0.46, // "DESIGNED IN LAYERS" beat, camera settles to top view
  explodeStart: 0.46,
  explodeEnd: 0.62, // full exploded view with labels
  coreDiveStart: 0.62,
  coreDiveEnd: 0.78, // camera enters absorbent core
  reconstructStart: 0.78,
  reconstructEnd: 0.9, // layers + wrapper reassemble
  finalStart: 0.9,
  finalEnd: 1.0, // final message
};
