/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        "hsn-black": "#050807",
        "hsn-green-deep": "#0B241D",
        "hsn-green-soft": "#BFDCCF",
        "hsn-white": "#F5F7F5",
        "hsn-gray": "#9CA8A3",
      },
      fontFamily: {
        sans: ["'Inter'", "system-ui", "sans-serif"],
      },
      letterSpacing: {
        widest2: "0.28em",
      },
      keyframes: {
        scrollcue: {
          "0%": { transform: "translateY(-16px)", opacity: "0" },
          "20%": { opacity: "1" },
          "80%": { opacity: "1" },
          "100%": { transform: "translateY(56px)", opacity: "0" },
        },
      },
      animation: {
        scrollcue: "scrollcue 2.2s ease-in-out infinite",
      },
    },
  },
  plugins: [],
};
